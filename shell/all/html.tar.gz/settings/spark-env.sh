export JAVA_HOME=/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.141.x86_64
export SCALA_HOME=/home/scala-2.10.5
export HADOOP_CONF_DIR=/home/hadoop/hadoop-2.6.5/etc/hadoop
export HADOOP_HOME=/home/hadoop-2.6.5
export SPARK_HOME=/home/hadoop/spark-1.6.0
export SPARK_MASTER_IP=NN
export SPARK_EXECUTOR_MEMORY=2g
export SPARK_DRIVE_MEMORY=1g

