<html>
   <body>
   <h1>Big Data</h1>
   <br>

   
   <br>
   <a href="sethadoop.php" target="showframe">hadoop配置</a>
   <br>
   <a href="setspark.php" target="showframe">spark配置</a>



<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>


   </body>
</html>
