<?php 
header("Content-Type:text/html;charset=utf-8");
?>
<html>
    <head>
        <title>Big Data</title>
    </head>
        <frameset cols="20%,80%">
        <frame src="page.php">
        <frame src="" name="showframe">
        </frameset>
    <body>
    </body>
</html>
